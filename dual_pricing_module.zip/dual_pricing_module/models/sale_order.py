from odoo import models, fields, api

class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    use_fulfilment_pricing = fields.Boolean(
        string='Use Fulfilment Pricing',
        default=False,
        help='Check this box to use fulfilment prices for all order lines'
    )
    
    @api.onchange('use_fulfilment_pricing')
    def _onchange_use_fulfilment_pricing(self):
        """Update all order line prices when fulfilment pricing is toggled"""
        if self.order_line:
            for line in self.order_line:
                if self.use_fulfilment_pricing:
                    # Switch to fulfilment price
                    if line.product_id.fulfilment_price > 0:
                        line.price_unit = line.product_id.fulfilment_price
                else:
                    # Switch back to manufacturing price
                    if line.product_id.manufacturing_price > 0:
                        line.price_unit = line.product_id.manufacturing_price
                    else:
                        # Fallback to list price
                        line.price_unit = line.product_id.list_price

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'
    
    @api.onchange('product_id')
    def _onchange_product_id_dual_pricing(self):
        """Set appropriate price based on order settings"""
        if self.product_id:
            if self.order_id.use_fulfilment_pricing and self.product_id.fulfilment_price > 0:
                self.price_unit = self.product_id.fulfilment_price
            elif self.product_id.manufacturing_price > 0:
                self.price_unit = self.product_id.manufacturing_price
            else:
                # Fallback to standard pricing
                super()._onchange_product_id_dual_pricing()
    
    def _get_display_price(self, product):
        """Override to use manufacturing price for customer portals"""
        if hasattr(self.env.context, 'website_id') and product.manufacturing_price > 0:
            return product.manufacturing_price
        return super()._get_display_price(product)