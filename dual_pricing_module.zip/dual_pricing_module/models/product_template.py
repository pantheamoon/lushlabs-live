from odoo import models, fields, api

class ProductTemplate(models.Model):
    _inherit = 'product.template'
    
    # Dual pricing fields
    manufacturing_price = fields.Float(
        string='Manufacturing Price',
        digits='Product Price',
        help='Price shown on customer portals for ordering'
    )
    
    fulfilment_price = fields.Float(
        string='Fulfilment Price', 
        digits='Product Price',
        help='Internal price used for fulfilment orders'
    )
    
    # Website visibility fields for multi-website setup
    website_star_seed = fields.Boolean(
        string='Available on Star Seed Portal',
        default=False,
        help='Make this product visible on Star Seed customer portal'
    )
    
    website_its_sugar = fields.Boolean(
        string='Available on Its Sugar Portal', 
        default=False,
        help='Make this product visible on Its Sugar customer portal'
    )
    
    # Low stock notification threshold
    low_stock_threshold = fields.Float(
        string='Low Stock Alert Threshold',
        default=10.0,
        help='Send notifications when stock falls below this level'
    )
    
    @api.model
    def get_website_price(self, website_id=None):
        """Get the appropriate price for website display"""
        # Always show manufacturing price on customer portals
        return self.manufacturing_price or self.list_price
    
    @api.model
    def check_low_stock_alerts(self):
        """Cron job to check for low stock and send notifications"""
        low_stock_products = self.search([
            ('qty_available', '<=', 'low_stock_threshold'),
            ('low_stock_threshold', '>', 0)
        ])
        
        for product in low_stock_products:
            # Send notification to customers who can access this product
            self._send_low_stock_notification(product)
    
    def _send_low_stock_notification(self, product):
        """Send low stock notification to relevant customers"""
        # Get customers based on website access
        customers = []
        
        if product.website_star_seed:
            # Get Star Seed customers
            star_seed_customers = self.env['res.partner'].search([
                ('website_id', '=', self._get_star_seed_website_id())
            ])
            customers.extend(star_seed_customers)
            
        if product.website_its_sugar:
            # Get Its Sugar customers  
            its_sugar_customers = self.env['res.partner'].search([
                ('website_id', '=', self._get_its_sugar_website_id())
            ])
            customers.extend(its_sugar_customers)
        
        # Send email notifications
        for customer in customers:
            self._send_email_notification(customer, product)
    
    def _get_star_seed_website_id(self):
        """Get Star Seed website ID"""
        website = self.env['website'].search([('domain', 'ilike', 'lushlabsstarseed.com')], limit=1)
        return website.id if website else False
        
    def _get_its_sugar_website_id(self):
        """Get Its Sugar website ID"""
        website = self.env['website'].search([('domain', 'ilike', 'lushlabsitssugar.com')], limit=1)
        return website.id if website else False
    
    def _send_email_notification(self, customer, product):
        """Send low stock email notification"""
        template = self.env.ref('dual_pricing_module.low_stock_email_template', raise_if_not_found=False)
        if template:
            template.send_mail(
                product.id,
                force_send=True,
                email_values={
                    'email_to': customer.email,
                    'subject': f'Low Stock Alert: {product.name}'
                }
            )