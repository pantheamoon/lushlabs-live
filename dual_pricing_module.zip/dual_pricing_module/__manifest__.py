{
    'name': 'Dual Pricing System',
    'version': '18.0.1.0.0',
    'category': 'Sales',
    'summary': 'Manufacturing and Fulfilment Pricing for Products',
    'description': """
        This module adds dual pricing functionality to products:
        - Manufacturing Price: Shown on customer portals
        - Fulfilment Price: Used for internal orders
        - Sales Order checkbox to switch all lines to fulfilment pricing
        - Single product, single inventory, dual pricing
    """,
    'author': 'Lush Labs Natural',
    'website': 'https://lushlabsnatural.com',
    'depends': ['base', 'product', 'sale', 'website_sale'],
    'data': [
        'views/product_template_views.xml',
        'views/sale_order_views.xml',
        'views/website_sale_templates.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}