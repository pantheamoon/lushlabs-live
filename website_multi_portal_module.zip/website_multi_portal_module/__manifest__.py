{
    'name': 'Multi-Website Customer Portals',
    'version': '18.0.1.0.0',
    'category': 'Website',
    'summary': 'Separate Customer Portals for Star Seed and Its Sugar',
    'description': """
        Multi-website customer portal system:
        - Separate portals for Star Seed and Its Sugar
        - Product visibility per website
        - Custom branding and menus per portal
        - Isolated customer access
        - Live inventory display on product listings
        - Order tracking integration
    """,
    'author': 'Lush Labs Natural',
    'website': 'https://lushlabsnatural.com',
    'depends': ['base', 'website', 'website_sale', 'portal', 'dual_pricing_module', 'shipping_integration_module'],
    'data': [
        'data/website_data.xml',
        'views/website_templates.xml',
        'views/portal_templates.xml',
        'views/product_website_views.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}