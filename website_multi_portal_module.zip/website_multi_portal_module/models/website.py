from odoo import models, fields, api

class Website(models.Model):
    _inherit = 'website'
    
    # Website-specific product filtering
    def _get_website_products(self):
        """Get products available for this website"""
        domain = [('sale_ok', '=', True)]
        
        if 'lushlabsstarseed.com' in (self.domain or ''):
            domain.append(('website_star_seed', '=', True))
        elif 'lushlabsitssugar.com' in (self.domain or ''):
            domain.append(('website_its_sugar', '=', True))
        
        return self.env['product.template'].search(domain)
    
    def _get_website_customers(self):
        """Get customers assigned to this website"""
        return self.env['res.partner'].search([
            ('website_id', '=', self.id),
            ('is_company', '=', False)
        ])

class WebsiteController(models.Model):
    _inherit = 'website'
    
    @api.model
    def get_current_website_products(self, **kwargs):
        """API method to get products for current website"""
        website = self.get_current_website()
        return website._get_website_products()