from odoo import models, fields, api

class ProductTemplate(models.Model):
    _inherit = 'product.template'
    
    @api.model
    def _search_get_detail(self, website, order, options):
        """Override search to filter by website visibility"""
        result = super()._search_get_detail(website, order, options)
        
        # Add website-specific domain
        if website:
            website_domain = []
            if 'lushlabsstarseed.com' in (website.domain or ''):
                website_domain = [('website_star_seed', '=', True)]
            elif 'lushlabsitssugar.com' in (website.domain or ''):
                website_domain = [('website_its_sugar', '=', True)]
            
            if website_domain:
                result['base_domain'] = result.get('base_domain', []) + website_domain
        
        return result
    
    def _is_available_on_website(self, website):
        """Check if product is available on specific website"""
        if not website:
            return True
            
        if 'lushlabsstarseed.com' in (website.domain or ''):
            return self.website_star_seed
        elif 'lushlabsitssugar.com' in (website.domain or ''):
            return self.website_its_sugar
        
        return True
    
    def _get_website_price(self, website=None):
        """Get appropriate price for website display"""
        # Always show manufacturing price on customer portals
        if self.manufacturing_price > 0:
            return self.manufacturing_price
        return self.list_price
    
    @api.model
    def _get_website_sale_domain(self, website):
        """Override to add website-specific filtering"""
        domain = super()._get_website_sale_domain(website)
        
        if website:
            if 'lushlabsstarseed.com' in (website.domain or ''):
                domain += [('website_star_seed', '=', True)]
            elif 'lushlabsitssugar.com' in (website.domain or ''):
                domain += [('website_its_sugar', '=', True)]
        
        return domain