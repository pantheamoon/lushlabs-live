from odoo import models, fields, api

class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    website_portal_type = fields.Selection([
        ('star_seed', 'Star Seed Portal'),
        ('its_sugar', 'Its Sugar Portal'),
        ('main', 'Main Portal')
    ], string='Portal Type', compute='_compute_website_portal_type', store=True)
    
    @api.depends('website_id')
    def _compute_website_portal_type(self):
        """Determine which portal the order came from"""
        for order in self:
            if order.website_id:
                if 'lushlabsstarseed.com' in (order.website_id.domain or ''):
                    order.website_portal_type = 'star_seed'
                elif 'lushlabsitssugar.com' in (order.website_id.domain or ''):
                    order.website_portal_type = 'its_sugar'
                else:
                    order.website_portal_type = 'main'
            else:
                order.website_portal_type = 'main'
    
    def _get_portal_tracking_url(self):
        """Get tracking URL for customer portal"""
        if self.website_id and hasattr(self, 'tracking_url') and self.tracking_url:
            return self.tracking_url
        return False
    
    def _get_portal_order_url(self):
        """Get order URL for customer portal"""
        base_url = self.website_id.get_base_url() if self.website_id else self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        return f"{base_url}/my/orders/{self.id}"

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'
    
    def _get_website_price(self):
        """Get price for website display"""
        if self.product_id.manufacturing_price > 0:
            return self.product_id.manufacturing_price
        return self.product_id.list_price