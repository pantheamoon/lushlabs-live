{
    'name': 'Sendcloud Shipping Integration',
    'version': '18.0.1.0.0',
    'category': 'Inventory/Delivery',
    'summary': 'Sendcloud Integration with Custom Shipping Logic',
    'description': """
        Advanced Sendcloud integration with custom shipping logic:
        - Royal Mail for Star Seed orders
        - Evri Postable for Discovery Kits
        - Evri 0-1kg for other products
        - £0.50-£1.00 profit margin per parcel
        - Automatic label generation and tracking updates
        - Customer portal tracking integration
    """,
    'author': 'Lush Labs Natural',
    'website': 'https://lushlabsnatural.com',
    'depends': ['base', 'sale', 'stock', 'delivery', 'website_sale', 'dual_pricing_module'],
    'data': [
        'data/delivery_carrier_data.xml',
        'views/delivery_carrier_views.xml',
        'views/sale_order_views.xml',
        'views/stock_picking_views.xml',
        'views/website_sale_templates.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}