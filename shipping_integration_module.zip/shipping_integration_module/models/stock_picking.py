from odoo import models, fields, api
import requests

class StockPicking(models.Model):
    _inherit = 'stock.picking'
    
    # Enhanced tracking fields
    carrier_tracking_url = fields.Char(string='Tracking URL', readonly=True)
    shipping_label_url = fields.Char(string='Shipping Label URL', readonly=True)
    sendcloud_parcel_id = fields.Char(string='Sendcloud Parcel ID', readonly=True)
    
    # Shipping status tracking
    shipping_status = fields.Selection([
        ('pending', 'Pending'),
        ('processed', 'Processed'),
        ('in_transit', 'In Transit'),
        ('delivered', 'Delivered'),
        ('exception', 'Exception')
    ], string='Shipping Status', default='pending', readonly=True)
    
    def action_generate_shipping_label(self):
        """Generate shipping label via Sendcloud"""
        if not self.carrier_id:
            raise UserError("No shipping carrier selected")
        
        if not hasattr(self.carrier_id, 'sendcloud_send_shipping'):
            raise UserError("Carrier does not support Sendcloud integration")
        
        # Generate label
        result = self.carrier_id.sendcloud_send_shipping([self])
        
        if result and result[0].get('tracking_number'):
            self.write({
                'shipping_status': 'processed',
                'carrier_tracking_ref': result[0]['tracking_number'],
                'carrier_tracking_url': f'https://tracking.sendcloud.sc/{result[0]["tracking_number"]}'
            })
            
            # Update sale order with tracking info
            if self.sale_id:
                self.sale_id.tracking_url = self.carrier_tracking_url
            
            # Send tracking info to customer portal
            self._update_customer_portal_tracking()
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Success',
                    'message': f'Shipping label generated. Tracking: {self.carrier_tracking_ref}',
                    'type': 'success'
                }
            }
        else:
            raise UserError("Failed to generate shipping label")
    
    def _update_customer_portal_tracking(self):
        """Update customer portal with tracking information"""
        if self.sale_id and self.carrier_tracking_ref:
            # Create tracking message for customer
            message = f"""
            <p><strong>Your order has been shipped!</strong></p>
            <p><strong>Tracking Number:</strong> {self.carrier_tracking_ref}</p>
            <p><strong>Carrier:</strong> {self.carrier_id.name}</p>
            <p><a href="{self.carrier_tracking_url}" target="_blank" class="btn btn-primary">Track Your Package</a></p>
            """
            
            self.sale_id.message_post(
                body=message,
                subject="Order Shipped - Tracking Information",
                message_type='notification',
                subtype_xmlid='mail.mt_note'
            )
    
    @api.model
    def _cron_update_shipping_status(self):
        """Cron job to update shipping status from Sendcloud"""
        pickings = self.search([
            ('shipping_status', 'in', ['processed', 'in_transit']),
            ('carrier_tracking_ref', '!=', False),
            ('sendcloud_parcel_id', '!=', False)
        ])
        
        for picking in pickings:
            try:
                status = self._get_sendcloud_tracking_status(picking)
                if status != picking.shipping_status:
                    picking.shipping_status = status
                    picking._notify_status_change(status)
            except Exception as e:
                # Log error but continue processing other pickings
                _logger.warning(f"Failed to update shipping status for {picking.name}: {e}")
    
    def _get_sendcloud_tracking_status(self, picking):
        """Get current shipping status from Sendcloud"""
        if not picking.carrier_id.sendcloud_api_key:
            return picking.shipping_status
        
        url = f"https://panel.sendcloud.sc/api/v2/parcels/{picking.sendcloud_parcel_id}"
        
        headers = {
            'Authorization': f'Basic {picking.carrier_id._get_auth_token()}',
            'Content-Type': 'application/json'
        }
        
        try:
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            sendcloud_status = data['parcel']['status']['message'].lower()
            
            # Map Sendcloud status to our status
            status_mapping = {
                'ready_to_send': 'processed',
                'being_sorted': 'in_transit',
                'in_transit': 'in_transit',
                'delivered': 'delivered',
                'exception': 'exception',
                'returned': 'exception'
            }
            
            return status_mapping.get(sendcloud_status, picking.shipping_status)
            
        except Exception as e:
            return picking.shipping_status
    
    def _notify_status_change(self, new_status):
        """Notify customer of shipping status change"""
        if not self.sale_id:
            return
        
        status_messages = {
            'in_transit': 'Your package is now in transit!',
            'delivered': 'Your package has been delivered!',
            'exception': 'There was an issue with your delivery. Please contact us.'
        }
        
        message = status_messages.get(new_status)
        if message:
            self.sale_id.message_post(
                body=f"<p><strong>Shipping Update:</strong> {message}</p>",
                subject="Shipping Status Update",
                message_type='notification'
            )
    
    def action_view_tracking(self):
        """Open tracking URL in new window"""
        if self.carrier_tracking_url:
            return {
                'type': 'ir.actions.act_url',
                'url': self.carrier_tracking_url,
                'target': 'new'
            }
        else:
            raise UserError("No tracking information available")
    
    def button_validate(self):
        """Override to auto-generate shipping labels on validation"""
        result = super().button_validate()
        
        # Auto-generate shipping label for sales orders
        if self.sale_id and self.carrier_id and not self.carrier_tracking_ref:
            try:
                self.action_generate_shipping_label()
            except Exception as e:
                # Don't block validation if label generation fails
                self.message_post(
                    body=f"Warning: Failed to generate shipping label automatically: {e}",
                    message_type='notification'
                )
        
        return result