from odoo import models, fields, api

class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    # Shipping method selection
    preferred_shipping_method = fields.Selection([
        ('auto', 'Automatic (Recommended)'),
        ('royal_mail', 'Royal Mail'),
        ('evri_postable', 'Evri Postable'),
        ('evri_standard', 'Evri 0-1kg')
    ], string='Shipping Method', default='auto')
    
    # Tracking information
    tracking_url = fields.Char(string='Tracking URL', readonly=True)
    shipping_profit_margin = fields.Float(string='Shipping Profit Margin', readonly=True)
    
    @api.onchange('preferred_shipping_method')
    def _onchange_preferred_shipping_method(self):
        """Update carrier based on selected shipping method"""
        if self.preferred_shipping_method == 'auto':
            # Use automatic selection logic
            carrier = self.env['delivery.carrier'].get_shipping_method_for_order(self)
        else:
            # Use manually selected method
            carrier = self._get_carrier_by_method(self.preferred_shipping_method)
        
        if carrier:
            self.carrier_id = carrier.id
            # Recalculate shipping cost
            self._compute_delivery_price()
    
    def _get_carrier_by_method(self, method):
        """Get carrier based on shipping method"""
        if method == 'royal_mail':
            return self.env['delivery.carrier'].search([('is_royal_mail', '=', True)], limit=1)
        elif method == 'evri_postable':
            return self.env['delivery.carrier'].search([('is_evri_postable', '=', True)], limit=1)
        elif method == 'evri_standard':
            return self.env['delivery.carrier'].search([('is_evri_standard', '=', True)], limit=1)
        return False
    
    def _compute_delivery_price(self):
        """Override to include profit margin calculation"""
        super()._compute_delivery_price()
        
        if self.carrier_id:
            # Calculate and store profit margin
            rate_result = self.carrier_id.sendcloud_rate_shipment(self)
            if rate_result.get('success'):
                base_cost = self.carrier_id._get_sendcloud_shipping_cost(self)
                profit_margin = rate_result['price'] - base_cost
                self.shipping_profit_margin = profit_margin
    
    def action_confirm(self):
        """Override to set automatic shipping method on confirmation"""
        result = super().action_confirm()
        
        # Set automatic shipping method if not already set
        for order in self:
            if not order.carrier_id or order.preferred_shipping_method == 'auto':
                carrier = self.env['delivery.carrier'].get_shipping_method_for_order(order)
                if carrier:
                    order.carrier_id = carrier.id
                    order._compute_delivery_price()
        
        return result
    
    def _create_delivery_line(self, carrier, price_unit):
        """Override to include shipping method info in delivery line"""
        result = super()._create_delivery_line(carrier, price_unit)
        
        # Update delivery line name to include shipping method
        if result and carrier:
            method_name = self._get_shipping_method_display_name(carrier)
            result.name = f"{carrier.name} - {method_name}"
        
        return result
    
    def _get_shipping_method_display_name(self, carrier):
        """Get display name for shipping method"""
        if carrier.is_royal_mail:
            return "Royal Mail"
        elif carrier.is_evri_postable:
            return "Evri Postable"
        elif carrier.is_evri_standard:
            return "Evri 0-1kg"
        return "Standard Delivery"

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'
    
    def _is_delivery(self):
        """Override to handle custom delivery products"""
        result = super()._is_delivery()
        if not result and self.product_id:
            # Check if this is a custom shipping product
            return self.product_id.type == 'service' and 'shipping' in self.product_id.name.lower()
        return result