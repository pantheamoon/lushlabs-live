import requests
import json
from odoo import models, fields, api
from odoo.exceptions import UserError

class DeliveryCarrier(models.Model):
    _inherit = 'delivery.carrier'
    
    # Sendcloud integration fields
    sendcloud_api_key = fields.Char(string='Sendcloud API Key')
    sendcloud_api_secret = fields.Char(string='Sendcloud API Secret')
    sendcloud_service_point_id = fields.Char(string='Sendcloud Service Point ID')
    
    # Custom shipping logic fields
    is_royal_mail = fields.Boolean(string='Royal Mail Service', default=False)
    is_evri_postable = fields.Boolean(string='Evri Postable Service', default=False)
    is_evri_standard = fields.Boolean(string='Evri 0-1kg Service', default=False)
    
    # Profit margin settings
    profit_margin_min = fields.Float(string='Minimum Profit Margin (£)', default=0.50)
    profit_margin_max = fields.Float(string='Maximum Profit Margin (£)', default=1.00)
    
    @api.model
    def get_shipping_method_for_order(self, sale_order):
        """Determine appropriate shipping method based on order details"""
        
        # Check if this is a Star Seed order
        if self._is_star_seed_order(sale_order):
            return self.search([('is_royal_mail', '=', True)], limit=1)
        
        # Check if order contains Discovery Kits
        if self._has_discovery_kit(sale_order):
            return self.search([('is_evri_postable', '=', True)], limit=1)
        
        # Default to Evri 0-1kg for other products
        return self.search([('is_evri_standard', '=', True)], limit=1)
    
    def _is_star_seed_order(self, sale_order):
        """Check if order is from Star Seed website"""
        if sale_order.website_id:
            return 'lushlabsstarseed.com' in (sale_order.website_id.domain or '')
        return False
    
    def _has_discovery_kit(self, sale_order):
        """Check if order contains Discovery Kit products"""
        for line in sale_order.order_line:
            if 'discovery kit' in line.product_id.name.lower():
                return True
        return False
    
    def sendcloud_rate_shipment(self, order):
        """Get shipping rates from Sendcloud with profit margin"""
        if not self.sendcloud_api_key or not self.sendcloud_api_secret:
            raise UserError("Sendcloud API credentials not configured")
        
        # Get base shipping cost from Sendcloud
        base_cost = self._get_sendcloud_shipping_cost(order)
        
        # Add profit margin
        profit_margin = self._calculate_profit_margin(order)
        final_cost = base_cost + profit_margin
        
        return {
            'success': True,
            'price': final_cost,
            'error_message': False,
            'warning_message': False
        }
    
    def _get_sendcloud_shipping_cost(self, order):
        """Get actual shipping cost from Sendcloud API"""
        url = "https://panel.sendcloud.sc/api/v2/shipping-price"
        
        headers = {
            'Authorization': f'Basic {self._get_auth_token()}',
            'Content-Type': 'application/json'
        }
        
        # Prepare shipment data
        shipment_data = {
            'parcel': {
                'weight': self._calculate_total_weight(order),
                'length': 20,  # Default dimensions
                'width': 15,
                'height': 10
            },
            'to_address': {
                'country': order.partner_shipping_id.country_id.code,
                'postal_code': order.partner_shipping_id.zip
            },
            'shipping_method': self._get_sendcloud_method_id()
        }
        
        try:
            response = requests.post(url, headers=headers, json=shipment_data, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            return float(data.get('price', 5.00))  # Default fallback price
            
        except Exception as e:
            # Fallback pricing if API fails
            return self._get_fallback_price(order)
    
    def _calculate_profit_margin(self, order):
        """Calculate profit margin between min and max based on order value"""
        order_total = order.amount_total
        
        if order_total < 50:
            return self.profit_margin_min
        elif order_total > 200:
            return self.profit_margin_max
        else:
            # Scale profit margin based on order value
            ratio = (order_total - 50) / 150  # 150 = 200 - 50
            margin_range = self.profit_margin_max - self.profit_margin_min
            return self.profit_margin_min + (ratio * margin_range)
    
    def _calculate_total_weight(self, order):
        """Calculate total weight of order"""
        total_weight = 0
        for line in order.order_line:
            if line.product_id.weight:
                total_weight += line.product_id.weight * line.product_uom_qty
        return max(total_weight, 0.1)  # Minimum 0.1kg
    
    def _get_sendcloud_method_id(self):
        """Get Sendcloud method ID based on carrier type"""
        if self.is_royal_mail:
            return 1  # Royal Mail method ID
        elif self.is_evri_postable:
            return 2  # Evri Postable method ID
        elif self.is_evri_standard:
            return 3  # Evri 0-1kg method ID
        return 1  # Default
    
    def _get_fallback_price(self, order):
        """Fallback pricing when API is unavailable"""
        if self.is_royal_mail:
            return 3.50
        elif self.is_evri_postable:
            return 2.95
        elif self.is_evri_standard:
            return 4.25
        return 5.00
    
    def _get_auth_token(self):
        """Generate base64 auth token for Sendcloud API"""
        import base64
        credentials = f"{self.sendcloud_api_key}:{self.sendcloud_api_secret}"
        return base64.b64encode(credentials.encode()).decode()
    
    def sendcloud_send_shipping(self, pickings):
        """Create shipping labels via Sendcloud"""
        result = []
        
        for picking in pickings:
            try:
                # Create shipment in Sendcloud
                shipment_data = self._prepare_shipment_data(picking)
                tracking_number = self._create_sendcloud_shipment(shipment_data)
                
                # Update picking with tracking info
                picking.write({
                    'carrier_tracking_ref': tracking_number,
                    'carrier_tracking_url': f'https://tracking.sendcloud.sc/{tracking_number}'
                })
                
                result.append({
                    'exact_price': picking.sale_id.carrier_id.sendcloud_rate_shipment(picking.sale_id)['price'],
                    'tracking_number': tracking_number
                })
                
            except Exception as e:
                result.append({
                    'exact_price': 0.0,
                    'tracking_number': False
                })
        
        return result
    
    def _prepare_shipment_data(self, picking):
        """Prepare shipment data for Sendcloud API"""
        order = picking.sale_id
        
        return {
            'parcel': {
                'name': order.partner_shipping_id.name,
                'company_name': order.partner_shipping_id.commercial_company_name or '',
                'address': order.partner_shipping_id.street,
                'address_2': order.partner_shipping_id.street2 or '',
                'city': order.partner_shipping_id.city,
                'postal_code': order.partner_shipping_id.zip,
                'country': order.partner_shipping_id.country_id.code,
                'telephone': order.partner_shipping_id.phone or '',
                'email': order.partner_shipping_id.email or order.partner_id.email,
                'weight': int(self._calculate_total_weight(order) * 1000),  # Convert to grams
                'order_number': order.name,
                'insured_value': int(order.amount_total * 100),  # Convert to cents
            },
            'shipment': {
                'id': self._get_sendcloud_method_id()
            }
        }
    
    def _create_sendcloud_shipment(self, shipment_data):
        """Create shipment in Sendcloud and return tracking number"""
        url = "https://panel.sendcloud.sc/api/v2/parcels"
        
        headers = {
            'Authorization': f'Basic {self._get_auth_token()}',
            'Content-Type': 'application/json'
        }
        
        try:
            response = requests.post(url, headers=headers, json=shipment_data, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            return data['parcel']['tracking_number']
            
        except Exception as e:
            raise UserError(f"Failed to create Sendcloud shipment: {str(e)}")